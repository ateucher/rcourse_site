my_sum <- function(a, b) {
  # check that a is numeric
  if (!(is.numeric(a) & is.numeric(b))) {
    stop("a and b must be numeric")
  } else {
    message("Hooray! function proceeding!")
  }

  the_sum <- a + b
  return(the_sum)
}

f_to_c <- function(temp) {
  if (!is.numeric(temp)) stop("temp must be numeric. Dummy.")
  if (temp > 5000) {
    warning("This is a really high temperature. Are you sure?")
  }

  celcius <- (temp - 32) * 5 / 9
  return(celcius)
}

f_to_k <- function(temp) {
  if (!is.numeric(temp)) stop("temp must be numeric. Dummy.")
  if (temp > 5000) {
    warning("This is a really high temperature. Are you sure?")
  }

  kelvin <- f_to_c(temp) + 273.15
  return(kelvin)
}








# First install a package from CRAN
# install.packages("ggplot2")
# Put package loading steps at the top of script
library(ggplot2)

## Read in the data from a csv to a data.frame
gapminder <- read.csv("data/gapminder-FiveYearData.csv",
                      stringsAsFactors = FALSE)

## Base plotting
## To save a plot, you first must open a graphics device
## (png, jpeg, etc), then plot it, then close the graphics
## device with dev.off()
jpeg(filename = "outputs/mybaseplot.jpg") # open the jpeg device
plot(x = gapminder$lifeExp, y = gapminder$gdpPercap)
dev.off() # close the jpeg device

# using formula syntax: y ~ x, data =
plot(gdpPercap ~ lifeExp, data = gapminder)

# histograms
hist(gapminder$gdpPercap)
hist(gapminder$pop)

# boxplot
boxplot(gdpPercap ~ continent, data = gapminder)
boxplot(gapminder$gdpPercap)

gg <- ggplot(gapminder, aes(x = gdpPercap, alpha = 0.5)) +
  geom_density(aes(fill = continent)) +
  scale_x_log10() +
  facet_wrap(~ year)

plot(gg)

## Saving a ggplot2 object using ggsave
ggsave(filename = "outputs/my_gg.pdf", plot = gg,
       width = 6, height = 4, units = "in", dpi = 120)

ggtitle("Density Plots of Continents by Year") +
  labs(x = "GDP per Capita", y = "Year", fill = "Continent") +

## ggplot2

ggplot(gapminder, aes(x = lifeExp, y = gdpPercap)) +
  geom_point()

# see what the column names are:
names(gapminder)

# how life expectancy has changed over time
ggplot(gapminder, aes(x = year, y = lifeExp)) +
  geom_point()

# Colour by continent:
ggplot(gapminder, aes(x = year, y = lifeExp, colour = continent)) +
  geom_point()

ggplot(gapminder, aes(x = year, y = lifeExp, by = country, colour = continent)) +
  geom_line()

ggplot(gapminder, aes(x = gdpPercap)) + geom_histogram()

# boxplot
ggplot(gapminder, aes(x = continent, y = gdpPercap)) + geom_boxplot()

ggplot(gapminder, aes(x = lifeExp, y = gdpPercap, colour = continent)) +
  geom_point() +
  scale_y_log10()

## add a best fit line
ggplot(gapminder, aes(x = lifeExp, y = gdpPercap, colour = continent)) +
  geom_point() +
  scale_y_log10() +
  geom_smooth(method = "lm")

## Facets: small multiples
ggplot(gapminder, aes(x = year, y = lifeExp, colour = continent)) +
  geom_line() +
  facet_wrap(~country) # use the tilde ~ to specify

ggplot(gapminder, aes(x = pop)) +
  geom_histogram() +
  facet_wrap(~continent)

## Departure to talk about subsetting

x <- c(1, 3, 8, 9, 10, 42)
x[4]
x[2:5]
2:5
x[c(2,4)]
to_keep <- c(FALSE, TRUE, FALSE, TRUE, FALSE, TRUE)
x[to_keep]

x > 3

x[x > 3]

## keep all rows where continent is africa, and all columns
africa <- gapminder[gapminder$continent == "Africa", ]
 ## keep all rows and only columns country, year, gdpPercap
cty_gdp_year <- gapminder[ ,c(1,2,6)]
cty_gdp_year <- gapminder[ , c("country", "year", "gdpPercap")]
names(gapminder)
names(cty_gdp_year)

ggplot(gapminder, aes(x = gdpPercap, y = lifeExp, colour = continent)) +
  geom_point() +
  facet_grid(continent ~ year) +
  scale_x_log10() +
  geom_line()

ggplot(gapminder, aes(x = continent, y = gdpPercap)) + geom_violin()

## Plot a subset
africa <- gapminder[gapminder$continent == "Africa", ]

## plot pop vs gdp for african countries
ggplot(africa, aes(x = pop, y = gdpPercap)) +
  geom_point(aes(colour = country)) +
  facet_grid(~country) +
  guides(colour=FALSE)

ggplot(gapminder[gapminder$continent == "Africa", ], aes(x = pop, y = gdpPercap)) +
  geom_point(aes(colour = country)) +
  facet_grid(~country) +
  guides(colour=FALSE)

ggplot(gapminder, aes(x= gdpPercap, fill = continent)) +
geom_density(alpha = 0.5) +
scale_x_log10() +
facet_wrap(~ year) +
ggtitle("Density Plots of Continents by Year") +
labs(x = "GDP per Capita (log10)", fill = "Continent") +
theme_minimal()

ggplot(gapminder, aes(x = lifeExp, y = gdpPercap)) +
  geom_hex()

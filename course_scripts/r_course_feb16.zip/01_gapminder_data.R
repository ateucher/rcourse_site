## This is my script for staring to learn about data frames in R

# To send R commands from a script to the console, press CTRL+ENTER
# If nothing is hightlited it will send the whole line, or you can
# part of a line, or multiple lines and send all at once. You can select
# all the text in a file by pressing CTRL+A

## First read in data. Don't forget stringsAsFactors = FALSE!!

# you can use more than one line to call a function, but line breaks
# must be after a comma:
gapminder <- read.csv(file = "data/gapminder-FiveYearData.csv",
                      stringsAsFactors = FALSE)

summary(gapminder)

# str = structure
str(gapminder)
class(gapminder)
dim(gapminder)
nrow(gapminder)
ncol(gapminder)
class(gapminder$country)
head(gapminder)
head(gapminder, n = 20)
tail(gapminder, n = 20)


## For loops to repeat things

x <- c("tabby", "calico", "black",
       "white", "tuxedo")

for (f in x) {
  p <- paste("my cat is a", f)
  print(p)
}

library(dplyr)
library(ggplot2)

gapminder <- read.csv("data/gapminder-FiveYearData.csv",
                      stringsAsFactors = FALSE)

africa <- filter(gapminder, continent == "Africa")

african_countries <- unique(africa$country)

for (cnty in african_countries) {
  cnty_data <- filter(africa, country == cnty)

  gg <- ggplot(cnty_data, aes(x = year, y = gdpPercap)) +
    geom_point() +
    ggtitle(cnty)

  fname <- paste0("outputs/", cnty, "_plot.jpg")
  ggsave(fname, gg)
}




zim <- filter(gapminder, country == "Zimbabwe")

gg <- ggplot(zim, aes(x = year, y = gdpPercap)) +
  geom_point() +
  ggtitle("Zimbabwe")

plot(gg)

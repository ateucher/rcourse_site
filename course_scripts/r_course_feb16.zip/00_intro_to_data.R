## This is my script for staring to learn about data in R

# To send R commands from a script to the console, press CTRL+ENTER
# If nothing is hightlited it will send the whole line, or you can
# part of a line, or multiple lines and send all at once. You can select
# all the text in a file by pressing CTRL+A

x <- 1
x <- x * 5
y <- x ^ 2
rm(x)
rm(y)

## Read in data
cats <- read.csv(file = "data/feline_data.csv")
View(cats) # look at the data in a read-only view
cats # View the data
cats$coat # Access a single column using $
cats$weight
cats$weight + 2 # Can do operations on every element of a column
cats$weight # But it doesn't change the original.
cats$weight <- cats$weight + 2 # Must reassign back to the original column
paste("My cat's coat is", cats$coat)
cats$weight + cats$coat # Doesn't work! Can't add numbers to words
# See what class (data type) an object is
class(cats$weight)
class(cats$likes_string)
class(cats$coat)
class(1)
class(2L) # Specifically denote an integer with an L suffix
class(TRUE)
class(FALSE)
TRUE <- "R is awesome" # Can't assign new values to TRUE or FALSE
true <- "R is awesome"
T
T <- "R is awesome"
T
class("banana")

# Factors
cats$coat
class(cats$coat)
typeof(cats$coat)
cats$coat <- as.character(cats$coat)
cats$coat
class(cats$coat)

## To avoid factors ALWAYS add stringsAsFactors = FALSE to your read.csv call!!
cats <- read.csv(file = "data/feline_data.csv", stringsAsFactors = FALSE)
cats$coat # character
class(cats$coat) # character
?read.csv # get help on a function
cats
# Convert 1/0 representation to logical TRUE/FALSE
cats$likes_string <- as.logical(cats$likes_string)
cats
summary(cats)
str(cats)
str(cats$weight)

## Constructing vectors
x <- 1:100
x
str(x)
1:20
## Using the `c` function:
c(1,3,7,9,11)
c("a", "hello", "z")
c(TRUE, FALSE)

## Missing values represented by NA
c(1,3,7,NA ,5 , 7)
x <- c(1,3,7,9,11)
x
mean(x)
y <- c(1,3,7,NA ,5 , 7)
mean(y) # returns NA
mean(y, na.rm = TRUE) # use na.rm =TRUE to ignore NA in the calculation
min(y, na.rm = TRUE)
sum(y, na.rm = TRUE)

## Adding a new column based on an existing column
cats
cats$weight_in_g <- cats$weight * 1000
cats

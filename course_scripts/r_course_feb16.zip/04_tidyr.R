## Using tidyr to convert data between wide and long format

## install the tidyr package from CRAN:
# install.packages("tidyr")

library(tidyr)

## download data from the web:
download.file("http://ateucher.github.io/rcourse_site/data/gapminder_wide.csv",
              destfile = "data/gapminder_wide.csv")

gapminder <- read.csv("data/gapminder-FiveYearData.csv")
gap_wide <- read.csv("data/gapminder_wide.csv", stringsAsFactors = FALSE)

gap_long <- gather(gap_wide, key = obs_type, value = obs_value,
                   starts_with("pop"), starts_with("lifeExp"),
                   starts_with("gdpPercap"))

## Can do the same thing as above by telling gather which columns to NOT gather
gap_long <- gather(gap_wide, key = obs_type, value = obs_value,
                   -continent, -country)

gap_long <- separate(gap_long, col = obs_type, into = c("obs_type", "year"),
                     sep = "_")

gap_normal <- spread(gap_long, key = obs_type, value = obs_value)

## Let's go back to wide
gap_temp <- unite(gap_long, obs_type, obs_type, year, sep = "_")

gap_new_wide <- spread(gap_temp, key = obs_type, value = obs_value)









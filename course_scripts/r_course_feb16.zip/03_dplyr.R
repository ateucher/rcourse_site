## Dataframe manipulation with dplyr

## install package from CRAN using install.packages("pkgname")
# install.packages("dplyr")

## load the package into your workspace using library(pkgname)
library(dplyr) # you will get a message about masking functions. Don't worry about it

## load data
gapminder <- read.csv("data/gapminder-FiveYearData.csv",
                      stringsAsFactors = FALSE)

## base subsetting
## Select just rows
africa <- gapminder[gapminder$continent == "Africa", ]

## Select rows and columns
africa_pop <- gapminder[gapminder$continent == "Africa", c("country","pop")]

## Now let's use dplyr functions
## filter() allows us to select rows

big_africa_07 <- filter(gapminder, continent == "Africa",
                    year == 2007, pop > 1000000)

## combine OR statements with the | (bar)
africa_oceana_07 <- filter(gapminder,
                        (continent == "Africa" | continent == "Oceania") & year == 2007)

## Use select() function to select columns
gap_yr_cnt_gdp <- select(gapminder, year, country, gdpPercap)

## Drop columns by preceding the column name with a - sign
gap_no_continent <- select(gapminder, -continent)

## Create summary statistics for groups in a dataframe. Eg., mean gdp by continent
## First use group_by() to set the grouping variable(s),
## then use summarize to create new summary variable(s)
## for each level of the grouping variable (continent)
gap_grp_cont <- group_by(gapminder, continent)
gap_mean_gdp_cont <- summarize(gap_grp_cont,
                               mean_gdp = mean(gdpPercap),
                               max_pop = max(pop),
                               sd_gdp = sd(gdpPercap),
                               n_obs = n())

## Can combine operations using the 'pipe' operator: %>%. This sends the result
## of one command (group_by) into the next command (summarize)
gap_mean_gdp_cont <- group_by(gapminder, continent) %>%
  summarize(mean_gdp = mean(gdpPercap),
            max_pop = max(pop),
            sd_gdp = sd(gdpPercap),
            n_obs = n())

africa_summary <- gapminder %>% # use the gapminder data frame
  filter(continent == "Africa") %>% # use only data where continent is Africa
  group_by(country) %>% # group by country and year
  summarise(mean_pop = mean(pop), # summarize
            mean_gdp = mean(gdpPercap),
            n_obs = n())

world_summary <- gapminder %>%
  filter(year > 1980) %>%
  mutate(total_gdp = gdpPercap * pop) %>%
  group_by(continent, year) %>%
  summarise(mean_pop = mean(pop), # summarize
            mean_gdp = mean(gdpPercap),
            n_obs = n(),
            total_mean_gdp = mean(total_gdp)) # use the total_gdp column we created in mutate

## Write our summary data out to a csv file.
write.csv(world_summary, file = "outputs/world_summary.csv",
          row.names = FALSE)







